---
scheme_id: post_matric_sc
source_url: https://scholarships.gov.in
last_verified: sample-summary (replace with official PDF)
---
# Post-Matric Scholarship for Scheduled Caste Students

## Benefit
Financial assistance covering maintenance allowance and compulsory non-refundable fees for SC students studying at the post-matriculation level, which means Class 11 onwards including diploma, graduation and post-graduation in recognised institutions.

## Eligibility
Indian citizen belonging to the Scheduled Caste, studying at post-matric level in a recognised institution. The annual income of parents or guardians must not exceed ₹2.5 lakh. Students should renew each year with satisfactory attendance and progress.

## Documents
Aadhaar, caste certificate, income certificate, previous year marksheet, admission or bonafide certificate, bank passbook.

## How to apply
Register on the National Scholarship Portal (scholarships.gov.in) or on the state portal (MahaDBT in Maharashtra), fill the application, upload documents and submit to the institute for verification.
