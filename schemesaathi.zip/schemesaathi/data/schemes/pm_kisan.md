---
scheme_id: pm_kisan
source_url: https://pmkisan.gov.in
last_verified: sample-summary (replace with official PDF)
---
# PM-KISAN Samman Nidhi

## Benefit
Income support of ₹6,000 per year to eligible farmer families, paid in three equal instalments of ₹2,000 every four months directly into the bank account through Direct Benefit Transfer (DBT).

## Eligibility
Landholding farmer families who own cultivable land as per land records. e-KYC and Aadhaar seeding of the bank account are mandatory to receive instalments.

## Exclusion criteria
The following are NOT eligible: institutional landholders; farmer families in which any member holds or has held a constitutional post; former and present ministers, MPs, MLAs, mayors and district panchayat chairpersons; serving or retired officers and employees of central or state governments (except Multi Tasking Staff, Class IV and Group D); retired persons with monthly pension of ₹10,000 or more; persons who paid income tax in the last assessment year; and registered professionals such as doctors, engineers, lawyers and chartered accountants.

## Documents
Aadhaar card, land ownership papers, bank account details, mobile number.

## How to apply
Visit pmkisan.gov.in, open Farmers Corner and choose New Farmer Registration, or register through a Common Service Centre or the state nodal officer / revenue (talathi) office. Complete e-KYC.
