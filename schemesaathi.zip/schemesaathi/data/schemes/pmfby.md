---
scheme_id: pmfby
source_url: https://pmfby.gov.in
last_verified: sample-summary (replace with official PDF)
---
# Pradhan Mantri Fasal Bima Yojana (PMFBY)

## Benefit
Insurance coverage and financial support to farmers in case of crop loss due to natural calamities, pests and diseases for notified crops in notified areas.

## Premium
Farmers pay a maximum of 2% of the sum insured for Kharif food crops and oilseeds, 1.5% for Rabi food crops and oilseeds, and 5% for annual commercial and horticultural crops. The balance premium is shared by the central and state governments.

## Eligibility
All farmers including sharecroppers and tenant farmers growing notified crops in notified areas. Loanee farmers are enrolled automatically through their bank with an option to opt out; non-loanee farmers must enrol voluntarily before the cut-off date announced for each season.

## Documents
Aadhaar, bank passbook, land record or tenancy / sharecropping agreement, sowing declaration with crop details.

## How to apply
Apply on the pmfby.gov.in Farmer Corner, through your bank, a Common Service Centre or an insurance company agent before the season's last date.
