---
scheme_id: ssy
source_url: https://www.indiapost.gov.in
last_verified: sample-summary (replace with official PDF)
---
# Sukanya Samriddhi Yojana (SSY)

## Benefit
A government-backed savings account for a girl child with interest rate notified quarterly by the government. Deposits qualify for tax benefit under Section 80C in the old tax regime and interest is tax-free.

## Eligibility
The account can be opened by a parent or legal guardian for a girl child aged below 10 years. Only one account per girl child; a maximum of two accounts per family (three if twins or triplets).

## Rules
Minimum deposit ₹250 per year and maximum ₹1.5 lakh per year. Deposits for 15 years; account matures after 21 years from opening. Partial withdrawal of up to 50% is allowed after the girl turns 18 for higher education or marriage.

## Documents
Birth certificate of the girl child, identity and address proof of the guardian, passport photographs.

## How to apply
Visit any post office or authorised bank branch with the documents and the initial deposit.
