---
scheme_id: pmayg
source_url: https://pmayg.nic.in
last_verified: sample-summary (replace with official PDF)
---
# Pradhan Mantri Awas Yojana - Gramin (PMAY-G)

## Benefit
Financial assistance of ₹1.20 lakh in plain areas and ₹1.30 lakh in hilly and difficult areas for construction of a pucca house with a minimum 25 sq. m. area, plus support of ₹12,000 for a toilet under Swachh Bharat Mission (Gramin) and 90 or 95 days of unskilled wages under MGNREGA.

## Eligibility
Rural households that are houseless or living in kutcha or dilapidated houses, selected from the SECC 2011 data and Awaas+ survey and approved by the Gram Sabha. Households that already own a pucca house are not eligible. Households with motorised vehicles, mechanised farm equipment, government employees or high income may be excluded as per the exclusion criteria.

## Documents
Aadhaar, MGNREGA job card, bank account, Swachh Bharat toilet number if available, house-site proof.

## How to apply
Check the permanent wait list at the Gram Panchayat. Submit documents to the Gram Panchayat or Block Development Office. Funds are released in instalments linked to construction stages through the AwaasSoft system.
