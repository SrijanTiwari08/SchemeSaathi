---
scheme_id: namo_shetkari
source_url: https://www.myscheme.gov.in
last_verified: sample-summary (replace with official PDF)
---
# Namo Shetkari Mahasanman Nidhi Yojana (Maharashtra)

## Benefit
The Maharashtra government gives an additional ₹6,000 per year to farmers who are eligible beneficiaries of PM-KISAN, paid directly to the bank account in instalments.

## Eligibility
Farmers resident in Maharashtra who are registered PM-KISAN beneficiaries and satisfy the PM-KISAN land and exclusion criteria. Income-tax payers and other PM-KISAN excluded categories are not eligible.

## Application
There is generally no separate application. Beneficiaries identified through the PM-KISAN database receive the amount automatically. Keep PM-KISAN e-KYC and Aadhaar-bank seeding complete. Grievances can be raised at the Taluka Agriculture Office.
