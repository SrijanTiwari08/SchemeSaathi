---
scheme_id: ujjwala
source_url: https://www.pmuy.gov.in
last_verified: sample-summary (replace with official PDF)
---
# Pradhan Mantri Ujjwala Yojana (PMUY)

## Benefit
A deposit-free LPG connection for adult women from eligible poor households. Targeted subsidy on refills may apply; check the current notification.

## Eligibility
The applicant must be a woman aged 18 or above and a citizen of India. The household must belong to a BPL family or other eligible category such as SC/ST households, PMAY beneficiaries, Antyodaya Anna Yojana, forest dwellers, tea garden workers or the most backward classes. No other LPG connection should exist in the household.

## Documents
Aadhaar, BPL ration card or proof of eligibility category, bank account details, passport-size photo, and the KYC application form.

## How to apply
Collect the form from the nearest LPG distributor or download it from pmuy.gov.in, attach documents and submit it to the distributor.
