---
scheme_id: ladki_bahin
source_url: https://www.myscheme.gov.in
last_verified: sample-summary (replace with official PDF)
---
# Mukhyamantri Majhi Ladki Bahin Yojana (Maharashtra)

## Benefit
Monthly financial assistance of ₹1,500 to eligible women, paid by direct bank transfer. NOTE: the scheme rules, amounts and beneficiary verification have been revised since launch; always check the current government resolution.

## Eligibility
Women resident of Maharashtra aged 21 to 65 years (completed). Annual family income must not exceed ₹2.5 lakh. The woman should have an Aadhaar-linked bank account. Families paying income tax, families with members in regular government service, and families owning a four-wheeler (other than a tractor) are excluded.

## Documents
Aadhaar, Maharashtra domicile proof or ration card (yellow / orange), income certificate if no ration card, bank passbook, passport photo, self-declaration.

## How to apply
Apply through the official state portal or app, or through the Anganwadi / ward office. Keep the bank account Aadhaar-linked for DBT.
