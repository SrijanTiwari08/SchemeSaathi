---
scheme_id: pmjay
source_url: https://pmjay.gov.in
last_verified: sample-summary (replace with official PDF)
---
# Ayushman Bharat PM-JAY

## Benefit
Health cover of ₹5 lakh per family per year for secondary and tertiary care hospitalisation, cashless and paperless at empanelled public and private hospitals. There is no cap on family size or age.

## Eligibility
Eligibility is based on the deprivation and occupational criteria of the Socio-Economic Caste Census (SECC) 2011 for rural families and on occupational categories for urban families. In addition, all citizens aged 70 years and above are eligible for cover of ₹5 lakh per year irrespective of income (Ayushman Vay Vandana).

## Documents
Aadhaar card, ration card or SECC family proof, mobile number.

## How to apply
Check eligibility at mera.pmjay.gov.in or call 14555. Visit an Ayushman Mitra at an empanelled hospital or Common Service Centre and complete e-KYC to generate the Ayushman card.
