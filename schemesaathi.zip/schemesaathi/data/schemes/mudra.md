---
scheme_id: mudra
source_url: https://www.mudra.org.in
last_verified: sample-summary (replace with official PDF)
---
# Pradhan Mantri MUDRA Yojana

## Benefit
Collateral-free loans to non-corporate, non-farm small and micro enterprises. Shishu: up to ₹50,000. Kishor: ₹50,001 to ₹5 lakh. Tarun: ₹5 lakh to ₹10 lakh. Tarun Plus (announced in Budget 2024) allows higher limits for borrowers who repaid earlier Tarun loans.

## Eligibility
Any Indian citizen aged 18 or above who has a business plan for a non-farm activity in manufacturing, trading, services, or allied agricultural activities such as dairy, poultry and fisheries, and who needs credit up to ₹10 lakh. Artisans, shopkeepers, vendors and small service providers are covered.

## Documents
Aadhaar, PAN, address proof, business proof or quotation for machinery, Udyam registration where available, recent bank statements, photographs, and caste certificate if applicable.

## How to apply
Approach any bank, NBFC or micro-finance institution, or apply online through the Udyami Mitra portal.
