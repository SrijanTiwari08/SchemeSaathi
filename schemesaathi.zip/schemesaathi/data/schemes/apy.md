---
scheme_id: apy
source_url: https://www.myscheme.gov.in
last_verified: sample-summary (replace with official PDF)
---
# Atal Pension Yojana (APY)

## Benefit
Guaranteed monthly pension of ₹1,000, ₹2,000, ₹3,000, ₹4,000 or ₹5,000 from age 60, depending on the contribution chosen and the age of joining.

## Eligibility
Indian citizens aged 18 to 40 years with a savings bank or post office account and a mobile number. From 1 October 2022, income-tax payers are not eligible to join APY.

## Documents
Aadhaar, savings bank account details, mobile number and nominee details.

## How to apply
Visit your bank branch or post office, fill the APY registration form and give consent for auto-debit of the monthly contribution.
