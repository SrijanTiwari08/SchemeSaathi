"""Tool 2: Scheme Retriever (RAG over ChromaDB) with citation metadata."""
import config

_db = None


def get_db():
    global _db
    if _db is None:
        if not config.DB_DIR.exists():
            raise RuntimeError("Vector DB not found. Run:  python ingest.py")
        from langchain_chroma import Chroma
        from embeddings import E5Embeddings
        _db = Chroma(collection_name="schemes", persist_directory=str(config.DB_DIR),
                     embedding_function=E5Embeddings(config.EMBED_MODEL))
    return _db


def search(query: str, k: int | None = None, scheme_id: str | None = None) -> list[dict]:
    flt = {"scheme_id": scheme_id} if scheme_id else None
    docs = get_db().similarity_search(query, k=k or config.TOP_K, filter=flt)
    return [{
        "text": d.page_content,
        "source": d.metadata.get("source", "?"),
        "page": d.metadata.get("page", 1),
        "scheme_id": d.metadata.get("scheme_id"),
        "url": d.metadata.get("source_url", ""),
        "last_verified": d.metadata.get("last_verified", ""),
    } for d in docs]
