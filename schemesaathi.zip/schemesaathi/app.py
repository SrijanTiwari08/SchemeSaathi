"""Streamlit UI  (run: streamlit run app.py)"""
import streamlit as st
from agent import SchemeSaathi
from report import build_pdf
import config

st.set_page_config(page_title="SchemeSaathi", page_icon="🇮🇳", layout="wide")

ICON = {"ELIGIBLE": "✅", "NEED_INFO": "❓", "NOT_ELIGIBLE": "❌"}
SAMPLES = {
    "Farmer (English)": "I am a 45-year-old farmer from Maharashtra with 2 acres of land and annual income of ₹90,000.",
    "किसान (Hindi)": "मैं 45 साल का किसान हूँ, महाराष्ट्र में रहता हूँ, मेरे पास 2 एकड़ ज़मीन है और सालाना आमदनी 90,000 रुपये है।",
    "शेतकरी (Marathi)": "मी 45 वर्षांचा शेतकरी आहे, महाराष्ट्रात राहतो, माझ्याकडे 2 एकर जमीन आहे आणि वार्षिक उत्पन्न 90,000 रुपये आहे.",
    "Woman, BPL (English)": "I am a 35 year old woman from a village in Maharashtra, homemaker, BPL family, income 80000 a year, I have a 5 year old daughter and no gas connection.",
}


@st.cache_resource
def get_agent():
    return SchemeSaathi()


def new_state():
    st.session_state.session = SchemeSaathi.new_session()
    st.session_state.messages = []


def show_results(results, profile, key):
    elig = [r for r in results if r["status"] == "ELIGIBLE"]
    maybe = [r for r in results if r["status"] == "NEED_INFO"]
    no = [r for r in results if r["status"] == "NOT_ELIGIBLE"]
    c1, c2, c3 = st.columns(3)
    c1.metric("Eligible", len(elig)); c2.metric("Need info", len(maybe)); c3.metric("Not eligible", len(no))

    for group in (elig, maybe):
        for r in group:
            with st.expander(f"{ICON[r['status']]} {r['name']} — {r['benefit']}", expanded=r["status"] == "ELIGIBLE"):
                if r["conflict"]:
                    st.warning("The official document may conflict with the rule table. Please verify on the portal.")
                for p in r["passed"]:
                    st.markdown(f"- ✔ {p}")
                if r["missing"]:
                    st.info("Need to know: " + ", ".join(m.replace("_", " ") for m in r["missing"]))
                if r["llm_reason"]:
                    st.caption("Evidence check: " + r["llm_reason"])
                if r["checklist"]:
                    st.markdown("**📄 Documents to carry**")
                    for d in r["checklist"]:
                        st.checkbox(d, key=f"{key}-{r['id']}-{d}")
                if r["steps"]:
                    st.markdown("**🪜 How to apply**")
                    for i, s in enumerate(r["steps"], 1):
                        st.markdown(f"{i}. {s}")
                st.markdown(f"🔗 [{r['link']}]({r['link']})")
                if r["citations"]:
                    with st.popover("📚 Sources"):
                        for c in r["citations"]:
                            st.markdown(f"**{c['source']}, p.{c['page']}** — {c['snippet']}…")
    if no:
        with st.expander(f"❌ Not eligible ({len(no)}) — see why"):
            for r in no:
                st.markdown(f"**{r['name']}**")
                for f in r["failed"]:
                    st.markdown(f"- ✘ {f}")
    st.download_button("⬇️ Download PDF report", build_pdf(profile, results),
                       file_name="SchemeSaathi_report.pdf", mime="application/pdf", key=f"pdf-{key}")


if "session" not in st.session_state:
    new_state()

with st.sidebar:
    st.title("🇮🇳 SchemeSaathi")
    st.caption(f"LLM: {config.LLM_PROVIDER} / {config.LLM_MODEL}  •  Verify with LLM: {config.VERIFY_WITH_LLM}")
    st.subheader("Try a sample")
    for label, text in SAMPLES.items():
        if st.button(label, use_container_width=True):
            st.session_state.pending = text
    st.subheader("Your profile")
    st.json(st.session_state.session["profile"] or {"info": "nothing collected yet"})
    if st.button("🔄 Start over", use_container_width=True):
        new_state(); st.rerun()
    st.caption("Guidance only. Always confirm on the official portal.")

st.header("SchemeSaathi — find government schemes you qualify for")
st.write("Describe yourself in **English, हिंदी or मराठी**. I'll check official scheme documents and tell you what you qualify for, "
         "which documents to carry, and how to apply.")

last_results_idx = max((i for i, m in enumerate(st.session_state.messages) if m.get("results")), default=-1)
for i, m in enumerate(st.session_state.messages):
    with st.chat_message(m["role"]):
        st.markdown(m["content"])
        if m.get("sources"):
            st.caption("Sources: " + "; ".join(f"[{s['n']}] {s['source']} p.{s['page']}" for s in m["sources"]))
        if m.get("results") and i == last_results_idx:
            show_results(m["results"], st.session_state.session["profile"], key=str(i))

user_text = st.chat_input("e.g. I am a 28-year-old woman running a tailoring shop in Nagpur...")
user_text = st.session_state.pop("pending", None) or user_text

if user_text:
    st.session_state.messages.append({"role": "user", "content": user_text})
    with st.spinner("Reading scheme documents and checking eligibility..."):
        out = get_agent().handle(st.session_state.session, user_text)
    st.session_state.messages.append({"role": "assistant", "content": out["text"],
                                      "results": out.get("results"), "sources": out.get("sources")})
    st.rerun()
