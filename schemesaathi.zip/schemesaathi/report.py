"""Tool 6: PDF report generator (ReportLab)."""
from datetime import date
from io import BytesIO
from xml.sax.saxutils import escape
from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, ListFlowable, ListItem
import config

_CUSTOM = config.FONT_PATH.exists()
if _CUSTOM:
    pdfmetrics.registerFont(TTFont("Deva", str(config.FONT_PATH)))
FONT = "Deva" if _CUSTOM else "Helvetica"


def t(s) -> str:
    """Escape for ReportLab; make text safe for the built-in Helvetica font."""
    s = str(s)
    if not _CUSTOM:
        s = s.replace("₹", "Rs. ").replace("✓", "").replace("✗", "")
        s = s.encode("latin-1", "replace").decode("latin-1")
    return escape(s)


def build_pdf(profile: dict, results: list) -> bytes:
    buf = BytesIO()
    doc = SimpleDocTemplate(buf, pagesize=A4, leftMargin=36, rightMargin=36, topMargin=36, bottomMargin=36)
    ss = getSampleStyleSheet()
    body = ParagraphStyle("b", parent=ss["BodyText"], fontName=FONT, fontSize=10, leading=14)
    h1 = ParagraphStyle("h1", parent=ss["Title"], fontName=FONT)
    h2 = ParagraphStyle("h2", parent=ss["Heading2"], fontName=FONT, textColor=colors.HexColor("#1b5e20"))
    small = ParagraphStyle("s", parent=body, fontSize=8, textColor=colors.grey)

    def bullets(items, ordered=False):
        return ListFlowable([ListItem(Paragraph(t(i), body)) for i in items],
                            bulletType="1" if ordered else "bullet", leftIndent=14)

    story = [Paragraph("SchemeSaathi - Personalised Scheme Report", h1),
             Paragraph(t(f"Generated on {date.today():%d %b %Y}"), small), Spacer(1, 8)]

    rows = [[t(k.replace("_", " ").title()), t("Yes" if v is True else "No" if v is False else v)]
            for k, v in profile.items()]
    if rows:
        tbl = Table(rows, colWidths=[160, 340])
        tbl.setStyle(TableStyle([("FONTNAME", (0, 0), (-1, -1), FONT), ("FONTSIZE", (0, 0), (-1, -1), 9),
                                 ("GRID", (0, 0), (-1, -1), 0.25, colors.lightgrey),
                                 ("BACKGROUND", (0, 0), (0, -1), colors.whitesmoke)]))
        story += [Paragraph("Your profile", h2), tbl]

    for label, status in (("Schemes you are eligible for", "ELIGIBLE"), ("Need more information", "NEED_INFO")):
        group = [r for r in results if r["status"] == status]
        if not group:
            continue
        story.append(Paragraph(label, h1 if False else h2))
        for r in group:
            story += [Paragraph(f"<b>{t(r['name'])}</b>", body), Paragraph(t(f"Benefit: {r['benefit']}"), body)]
            if r["passed"]:
                story += [Paragraph("Why:", body), bullets(r["passed"])]
            if status == "NEED_INFO" and r["missing"]:
                story.append(Paragraph(t("Missing info: " + ", ".join(m.replace("_", " ") for m in r["missing"])), body))
            if r["checklist"]:
                story += [Paragraph("Documents to carry:", body), bullets(r["checklist"])]
            if r["steps"]:
                story += [Paragraph("How to apply:", body), bullets(r["steps"], ordered=True)]
            story.append(Paragraph(t(f"Official portal: {r['link']}"), body))
            if r["citations"]:
                story.append(Paragraph(t("Sources: " + "; ".join(sorted({f"{c['source']} p.{c['page']}" for c in r['citations']}))), small))
            story.append(Spacer(1, 10))

    story.append(Paragraph(t("Disclaimer: This report is guidance only, generated from documents in the knowledge base. "
                             "Always confirm eligibility and dates on the official portal or at your nearest CSC / Gram Panchayat."), small))
    doc.build(story)
    return buf.getvalue()
