"""SchemeSaathi agent: profile -> retrieve -> reason -> verify -> act.

The orchestration is an explicit, inspectable state machine (more reliable on free-tier LLMs
than free-form ReAct), while every step is a tool call that may use the LLM.
"""
import json
from collections import Counter
import config, rules, tools
from models import (merge_profile, missing_core, FIELD_QUESTIONS)

ORDER = {rules.ELIGIBLE: 0, rules.NEED_INFO: 1, rules.NOT_ELIGIBLE: 2}


class SchemeSaathi:
    def __init__(self, verify: bool | None = None):
        self.schemes = json.loads(config.SCHEMES_JSON.read_text(encoding="utf-8"))
        self.verify = config.VERIFY_WITH_LLM if verify is None else verify

    @staticmethod
    def new_session():
        return {"profile": {}, "language": "en", "results": None}

    # ------------------------------------------------------------ matching
    def match(self, profile: dict, verify: bool | None = None) -> list:
        verify = self.verify if verify is None else verify
        results = []
        for s in self.schemes:
            r = rules.evaluate(profile, s)
            item = {
                "id": s["id"], "name": s["name"], "benefit": s["benefit"], "category": s["category"],
                "status": r["status"], "passed": r["passed"], "failed": r["failed"],
                "missing": r["missing"], "checklist": [], "steps": [], "link": s["link"],
                "citations": [], "llm_reason": "", "conflict": False, "priority": s.get("priority", 9),
            }
            if r["status"] != rules.NOT_ELIGIBLE:
                try:
                    ev = tools.retriever.search(s["query"], scheme_id=s["id"])
                    item["citations"] = [{"source": e["source"], "page": e["page"],
                                          "snippet": e["text"][:220].replace("\n", " ")} for e in ev]
                    if verify and ev:
                        v = tools.verify_with_llm(profile, s, r, ev)
                        item["llm_reason"], item["conflict"] = v["reason"], v["conflict"]
                        if v["conflict"] and v["verdict"] == rules.NOT_ELIGIBLE:
                            item["status"] = rules.NEED_INFO   # downgrade, ask the user to verify
                except Exception as e:                           # DB missing / LLM down: keep rule result
                    item["llm_reason"] = f"(Evidence check unavailable: {e})"
                item["checklist"] = tools.generate_checklist(profile, s)
                item["steps"] = tools.find_links(s)["steps"]
            results.append(item)
        results.sort(key=lambda x: (ORDER[x["status"]], x["priority"]))
        return results

    # ------------------------------------------------------------ helpers
    @staticmethod
    def followups(results, limit=3):
        c = Counter(f for r in results if r["status"] == rules.NEED_INFO for f in r["missing"])
        return [FIELD_QUESTIONS[f] for f, _ in c.most_common(limit)]

    def _summary(self, results, lang):
        elig = [r["name"] for r in results if r["status"] == rules.ELIGIBLE]
        maybe = [r["name"] for r in results if r["status"] == rules.NEED_INFO]
        base = (f"You appear eligible for {len(elig)} scheme(s): {', '.join(elig) or 'none yet'}. "
                f"{len(maybe)} more need a little extra information ({', '.join(maybe) or 'none'}). "
                "Details, document checklists and sources are below.")
        return tools.translate(base, lang)

    # ------------------------------------------------------------ main entry
    def handle(self, session: dict, text: str) -> dict:
        try:
            updates, lang = tools.extract_profile(text, session["profile"])
        except Exception as e:
            return {"type": "error", "text": f"LLM error: {e}"}
        if lang:
            session["language"] = lang
        lang = session["language"]

        changed = {k: v for k, v in updates.items() if session["profile"].get(k) != v}
        session["profile"] = merge_profile(session["profile"], updates)
        core_missing = missing_core(session["profile"])

        # Case 1: no new profile info -> grounded Q&A
        if not changed:
            try:
                qa = tools.rag_answer(text, session["profile"], lang)
            except Exception as e:
                return {"type": "error", "text": str(e)}
            msg = qa["answer"]
            if core_missing:
                msg += "\n\n" + tools.translate(
                    "To find schemes for you, please tell me: " + "; ".join(FIELD_QUESTIONS[f] for f in core_missing), lang)
            return {"type": "qa", "text": msg, "sources": qa["sources"]}

        # Case 2: profile incomplete -> ask follow-up instead of guessing
        if core_missing:
            q = "Thanks! I still need: " + "; ".join(FIELD_QUESTIONS[f] for f in core_missing)
            return {"type": "ask", "text": tools.translate(q, lang)}

        # Case 3: run the full agent pipeline
        results = self.match(session["profile"])
        session["results"] = results
        fu = self.followups(results)
        text_out = self._summary(results, lang)
        if fu:
            text_out += "\n\n" + tools.translate("To confirm the remaining schemes, tell me: " + "; ".join(fu), lang)
        return {"type": "results", "text": text_out, "results": results}
