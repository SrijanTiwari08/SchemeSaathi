"""Citizen profile schema, cleaning and follow-up questions."""

# field -> (type, description)
FIELDS = {
    "age": ("int", "age in years"),
    "gender": ("enum:male|female|other", "gender"),
    "state": ("str", "Indian state/UT, full English name e.g. Maharashtra"),
    "area_type": ("enum:rural|urban", "lives in a rural or urban area"),
    "occupation": ("enum:farmer|student|small_business|artisan|salaried|labourer|homemaker|unemployed|retired|other",
                   "main occupation (shopkeeper/self-employed -> small_business)"),
    "annual_income": ("float", "annual household income in INR"),
    "land_acres": ("float", "cultivable land owned, in acres (0 if none)"),
    "social_category": ("enum:General|OBC|SC|ST", "social category"),
    "is_bpl": ("bool", "belongs to a BPL / low-income deprived household"),
    "is_income_taxpayer": ("bool", "pays income tax"),
    "has_bank_account": ("bool", "has a bank/post-office savings account"),
    "owns_pucca_house": ("bool", "owns a pucca (concrete) house"),
    "has_lpg_connection": ("bool", "household already has an LPG connection"),
    "has_girl_child_under_10": ("bool", "has a girl child below 10 years"),
    "is_student": ("bool", "currently studying"),
    "education_level": ("enum:below_10|class_10|class_11_12|diploma|graduate|pg",
                        "current/highest education level"),
}

CORE_FIELDS = ["age", "state", "occupation", "annual_income"]

# Plain-English questions; the agent translates them to the user's language.
FIELD_QUESTIONS = {
    "age": "What is your age?",
    "gender": "What is your gender?",
    "state": "Which state do you live in?",
    "area_type": "Do you live in a rural area (village) or an urban area (city/town)?",
    "occupation": "What is your main occupation (farmer, student, small business, artisan, salaried, etc.)?",
    "annual_income": "What is your approximate annual family income in rupees?",
    "land_acres": "How many acres of cultivable land do you own (0 if none)?",
    "social_category": "Which category do you belong to (General, OBC, SC, ST)?",
    "is_bpl": "Does your family belong to the BPL / low-income category (ration card or BPL list)?",
    "is_income_taxpayer": "Do you or your family pay income tax?",
    "has_bank_account": "Do you have a bank or post-office savings account?",
    "owns_pucca_house": "Do you own a pucca (concrete) house?",
    "has_lpg_connection": "Does your household already have an LPG gas connection?",
    "has_girl_child_under_10": "Do you have a girl child below 10 years of age?",
    "is_student": "Are you currently studying?",
    "education_level": "What is your current education level (class 10, class 11-12, diploma, graduate, PG)?",
}


def spec_text() -> str:
    return "\n".join(f"- {k}: {t.replace('enum:', 'one of ')} ({d})" for k, (t, d) in FIELDS.items())


def clean_profile(raw: dict) -> dict:
    """Keep only known fields and coerce types; silently drop invalid values."""
    out = {}
    for key, (typ, _) in FIELDS.items():
        v = raw.get(key)
        if v is None or v == "":
            continue
        try:
            if typ == "int":
                v = int(float(v))
            elif typ == "float":
                v = float(v)
            elif typ == "bool":
                if isinstance(v, str):
                    v = {"true": True, "yes": True, "false": False, "no": False}[v.strip().lower()]
                else:
                    v = bool(v)
            elif typ.startswith("enum:"):
                opts = {o.lower(): o for o in typ[5:].split("|")}
                v = opts[str(v).strip().lower().replace(" ", "_")]
            else:
                v = str(v).strip()
        except (ValueError, KeyError, TypeError):
            continue
        out[key] = v
    if out.get("occupation") == "student":
        out["is_student"] = True
    return out


def merge_profile(old: dict, new: dict) -> dict:
    return {**old, **new}


def missing_core(profile: dict) -> list:
    return [f for f in CORE_FIELDS if profile.get(f) is None]
