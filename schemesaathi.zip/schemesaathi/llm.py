"""LLM provider factory + robust JSON helper."""
import json, re, time
from functools import lru_cache
import config


@lru_cache(maxsize=1)
def get_llm():
    p = config.LLM_PROVIDER
    if p == "gemini":
        from langchain_google_genai import ChatGoogleGenerativeAI
        return ChatGoogleGenerativeAI(model=config.LLM_MODEL, temperature=0)
    if p == "groq":
        from langchain_groq import ChatGroq
        return ChatGroq(model=config.LLM_MODEL, temperature=0)
    if p == "ollama":
        from langchain_ollama import ChatOllama
        return ChatOllama(model=config.LLM_MODEL, temperature=0)
    raise ValueError(f"Unknown LLM_PROVIDER '{p}'. Use gemini, groq or ollama.")


def ask(prompt: str, retries: int = 3) -> str:
    last = None
    for i in range(retries):
        try:
            out = get_llm().invoke(prompt).content
            return out if isinstance(out, str) else "".join(str(x) for x in out)
        except Exception as e:  # rate limits, transient errors
            last = e
            time.sleep(2 ** i)
    raise RuntimeError(f"LLM call failed: {last}")


def ask_json(prompt: str) -> dict:
    for _ in range(2):
        text = ask(prompt)
        text = re.sub(r"```(?:json)?", "", text).strip()
        m = re.search(r"\{.*\}", text, re.S)
        if m:
            try:
                return json.loads(m.group(0))
            except json.JSONDecodeError:
                continue
    return {}
