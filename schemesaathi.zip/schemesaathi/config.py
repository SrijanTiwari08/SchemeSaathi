"""Central configuration. Values can be overridden through a .env file."""
import os
from pathlib import Path
from dotenv import load_dotenv

load_dotenv()

ROOT = Path(__file__).parent
DOCS_DIR = ROOT / "data" / "schemes"          # scheme PDFs / .md files
SCHEMES_JSON = ROOT / "data" / "schemes.json"  # structured rules + checklists
DB_DIR = ROOT / "db"                           # ChromaDB persistence
FONT_PATH = ROOT / "assets" / "fonts" / "NotoSansDevanagari-Regular.ttf"

EMBED_MODEL = os.getenv("EMBED_MODEL", "intfloat/multilingual-e5-base")
LLM_PROVIDER = os.getenv("LLM_PROVIDER", "gemini").lower()
DEFAULT_MODELS = {
    "gemini": "gemini-2.0-flash",
    "groq": "llama-3.3-70b-versatile",
    "ollama": "llama3.1",
}
LLM_MODEL = os.getenv("LLM_MODEL") or DEFAULT_MODELS.get(LLM_PROVIDER, "")

CHUNK_SIZE = 800
CHUNK_OVERLAP = 120
TOP_K = 4
VERIFY_WITH_LLM = os.getenv("VERIFY_WITH_LLM", "true").lower() == "true"
