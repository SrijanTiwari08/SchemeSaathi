"""Hand-labelled test profiles. Each case overrides BASE; 'expected' = schemes that are truly ELIGIBLE.
Extend this list to 30-40 cases for the final report."""
BASE = dict(age=30, gender="male", state="Maharashtra", area_type="urban", occupation="salaried",
            annual_income=300000, land_acres=0, social_category="General", is_bpl=False,
            is_income_taxpayer=False, has_bank_account=True, owns_pucca_house=True,
            has_lpg_connection=True, has_girl_child_under_10=False, is_student=False,
            education_level="graduate")

CASES = [
 dict(id="base_salaried_30", over={}, expected=["apy"]),
 dict(id="mh_farmer_2acre", over=dict(age=45, occupation="farmer", land_acres=2, annual_income=90000,
      area_type="rural", owns_pucca_house=False), expected=["pm_kisan", "namo_shetkari", "pmfby", "pmayg"]),
 dict(id="mh_bpl_homemaker", over=dict(age=35, gender="female", occupation="homemaker", annual_income=80000,
      area_type="rural", is_bpl=True, has_lpg_connection=False, owns_pucca_house=False, has_girl_child_under_10=True),
      expected=["pmjay", "ujjwala", "apy", "pmayg", "ssy", "ladki_bahin"]),
 dict(id="sc_graduate_student", over=dict(age=20, occupation="student", is_student=True, annual_income=150000,
      social_category="SC"), expected=["apy", "post_matric_sc"]),
 dict(id="punjab_rich_farmer_taxpayer", over=dict(age=50, state="Punjab", occupation="farmer", land_acres=10,
      annual_income=1500000, is_income_taxpayer=True, area_type="rural"), expected=["pmfby"]),
 dict(id="mh_woman_shopkeeper", over=dict(age=28, gender="female", occupation="small_business", annual_income=200000),
      expected=["mudra", "apy", "ladki_bahin"]),
 dict(id="senior_72", over=dict(age=72, occupation="retired", annual_income=100000), expected=["pmjay"]),
 dict(id="karnataka_artisan_woman_bpl", over=dict(age=25, gender="female", state="Karnataka", occupation="artisan",
      annual_income=120000, is_bpl=True, has_lpg_connection=False, area_type="rural", owns_pucca_house=False),
      expected=["pmjay", "mudra", "ujjwala", "apy", "pmayg"]),
 dict(id="st_girl_17", over=dict(age=17, gender="female", occupation="student", is_student=True,
      annual_income=100000, social_category="ST", education_level="class_11_12"), expected=[]),
 dict(id="woman_66_over_age_limit", over=dict(age=66, gender="female", annual_income=100000, occupation="retired"), expected=[]),
 dict(id="woman_21_income_boundary", over=dict(age=21, gender="female", annual_income=250000), expected=["apy", "ladki_bahin"]),
 dict(id="landless_farmer_bpl_40", over=dict(age=40, occupation="farmer", land_acres=0, area_type="rural",
      owns_pucca_house=False, is_bpl=True, annual_income=60000), expected=["pmjay", "apy", "pmayg"]),
 dict(id="taxpayer_35", over=dict(age=35, is_income_taxpayer=True), expected=[]),
]


def load_cases():
    return [dict(id=c["id"], profile={**BASE, **c["over"]}, expected=c["expected"]) for c in CASES]
