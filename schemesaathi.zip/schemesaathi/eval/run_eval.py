"""Evaluate SchemeSaathi.   python -m eval.run_eval [--no-llm] [--baseline] [--retrieval]

--no-llm     rule engine only (no API key needed)
--baseline   also run a plain LLM (no RAG, no rules) for comparison -> hallucination reduction
--retrieval  measure retrieval hit-rate@k (needs `python ingest.py` first)
"""
import argparse, json, sys, pathlib
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent.parent))
import config, rules
from eval.cases import load_cases


def prf(pred_sets, gold_sets):
    tp = sum(len(p & g) for p, g in zip(pred_sets, gold_sets))
    fp = sum(len(p - g) for p, g in zip(pred_sets, gold_sets))
    fn = sum(len(g - p) for p, g in zip(pred_sets, gold_sets))
    prec = tp / (tp + fp) if tp + fp else 1.0
    rec = tp / (tp + fn) if tp + fn else 1.0
    f1 = 2 * prec * rec / (prec + rec) if prec + rec else 0.0
    exact = sum(p == g for p, g in zip(pred_sets, gold_sets)) / len(gold_sets)
    return dict(precision=round(prec, 3), recall=round(rec, 3), f1=round(f1, 3), exact_match=round(exact, 3),
                false_positive_rate=round(fp / (tp + fp), 3) if tp + fp else 0.0)


def baseline_llm(profile):
    from llm import ask_json
    schemes = json.loads(config.SCHEMES_JSON.read_text(encoding="utf-8"))
    listing = "\n".join(f"- {s['id']}: {s['name']}" for s in schemes)
    out = ask_json(f"Which of these Indian government schemes is this person eligible for?\n{listing}\n"
                   f"Profile: {json.dumps(profile)}\nReturn ONLY JSON: {{\"eligible\": [scheme ids]}}")
    return set(out.get("eligible", [])) & {s["id"] for s in schemes}


def retrieval_hit_rate(k=4):
    import retriever
    schemes = json.loads(config.SCHEMES_JSON.read_text(encoding="utf-8"))
    hits = sum(any(r["scheme_id"] == s["id"] for r in retriever.search(s["query"], k=k)) for s in schemes)
    return round(hits / len(schemes), 3)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--no-llm", action="store_true")
    ap.add_argument("--baseline", action="store_true")
    ap.add_argument("--retrieval", action="store_true")
    a = ap.parse_args()

    from agent import SchemeSaathi
    cases = load_cases()
    gold = [set(c["expected"]) for c in cases]
    agent = SchemeSaathi(verify=not a.no_llm)

    agent_pred = []
    for c in cases:
        res = agent.match(c["profile"])
        agent_pred.append({r["id"] for r in res if r["status"] == rules.ELIGIBLE})
    report = {"cases": len(cases), "agent": prf(agent_pred, gold)}

    if a.baseline:
        report["plain_llm_baseline"] = prf([baseline_llm(c["profile"]) for c in cases], gold)
    if a.retrieval:
        report["retrieval_hit_rate@4"] = retrieval_hit_rate()

    print(json.dumps(report, indent=2))
    pathlib.Path(__file__).with_name("results.json").write_text(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
