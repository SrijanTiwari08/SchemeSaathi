"""Build the vector DB from data/schemes/*.pdf and *.md  (run: python ingest.py).

File name (without extension) = scheme_id, e.g. pm_kisan.pdf -> scheme_id 'pm_kisan'.
Markdown files may start with a header:
---
scheme_id: pm_kisan
source_url: https://pmkisan.gov.in
last_verified: 2025-01-01
---
"""
import shutil
import config
from langchain_core.documents import Document
from langchain_text_splitters import RecursiveCharacterTextSplitter


def parse_md(path):
    raw = path.read_text(encoding="utf-8")
    meta = {}
    if raw.startswith("---"):
        _, header, raw = raw.split("---", 2)
        for line in header.strip().splitlines():
            if ":" in line:
                k, v = line.split(":", 1)
                meta[k.strip()] = v.strip()
    meta.setdefault("scheme_id", path.stem)
    meta.update(source=path.name, page=1)
    return [Document(page_content=raw.strip(), metadata=meta)]


def parse_pdf(path):
    from langchain_community.document_loaders import PyMuPDFLoader
    docs = PyMuPDFLoader(str(path)).load()          # keeps page numbers for citations
    for d in docs:
        d.metadata = {"scheme_id": path.stem, "source": path.name,
                      "page": int(d.metadata.get("page", 0)) + 1,
                      "source_url": "", "last_verified": ""}
    return docs


def main():
    docs = []
    for p in sorted(config.DOCS_DIR.iterdir()):
        if p.suffix.lower() == ".pdf":
            docs += parse_pdf(p)
        elif p.suffix.lower() in (".md", ".txt"):
            docs += parse_md(p)
    if not docs:
        raise SystemExit(f"No documents found in {config.DOCS_DIR}")

    chunks = RecursiveCharacterTextSplitter(
        chunk_size=config.CHUNK_SIZE, chunk_overlap=config.CHUNK_OVERLAP).split_documents(docs)

    if config.DB_DIR.exists():
        shutil.rmtree(config.DB_DIR)
    from langchain_chroma import Chroma
    from embeddings import E5Embeddings
    Chroma.from_documents(chunks, E5Embeddings(config.EMBED_MODEL), collection_name="schemes",
                          persist_directory=str(config.DB_DIR))
    print(f"Ingested {len(docs)} pages -> {len(chunks)} chunks into {config.DB_DIR}")


if __name__ == "__main__":
    main()
