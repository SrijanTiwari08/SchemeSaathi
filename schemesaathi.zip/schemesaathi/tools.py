"""Agent tools. Each function is one 'tool' in the agent's toolbox.

1 extract_profile        text -> structured JSON
2 retriever.search       RAG over official documents
3 check_eligibility      rule engine + LLM evidence verification
4 generate_checklist     personalised document list
5 find_links             official portal + application steps
6 report.build_pdf       downloadable summary
+ rag_answer             grounded Q&A with citations
+ translate              multilingual output
"""
import json
import rules, retriever
from llm import ask, ask_json
from models import spec_text, clean_profile

LANG_NAMES = {"en": "English", "hi": "Hindi", "mr": "Marathi"}


# ---------- Tool 1 ----------
def extract_profile(text: str, current: dict):
    prompt = f"""You extract a citizen's profile for matching Indian government schemes.
The message may be in English, Hindi, Marathi or mixed (Hinglish). Output ONLY one JSON object.
Keys (use null when not stated. NEVER guess):
{spec_text()}
- language: language of the message, one of "en", "hi", "mr"
Rules: amounts in INR per year (monthly x 12; 1 lakh = 100000). Land in acres (1 hectare = 2.47 acres).
Output only NEW or CORRECTED information compared with the known profile.
Known profile: {json.dumps(current, ensure_ascii=False)}
Message: {text}"""
    data = ask_json(prompt)
    lang = data.pop("language", None)
    return clean_profile(data), (lang if lang in LANG_NAMES else None)


# ---------- Tool 3 ----------
def verify_with_llm(profile: dict, scheme: dict, rule_result: dict, evidence: list) -> dict:
    ev = "\n".join(f"[{i+1}] ({e['source']}, p.{e['page']}) {e['text']}" for i, e in enumerate(evidence))
    prompt = f"""You are a careful eligibility auditor for the scheme "{scheme['name']}".
Use ONLY the evidence below. Do not use outside knowledge.
Profile: {json.dumps(profile, ensure_ascii=False)}
Rule-engine result: {json.dumps(rule_result, ensure_ascii=False)}
Evidence:
{ev}

Does the evidence contradict the rule-engine result (e.g. an exclusion criterion that applies to this profile)?
Return ONLY JSON: {{"verdict": "ELIGIBLE|NOT_ELIGIBLE|NEED_INFO", "reason": "max 2 sentences citing evidence numbers like [1]", "conflict": true|false}}"""
    out = ask_json(prompt)
    if out.get("verdict") not in (rules.ELIGIBLE, rules.NOT_ELIGIBLE, rules.NEED_INFO):
        return {"verdict": rule_result["status"], "reason": "", "conflict": False}
    return {"verdict": out["verdict"], "reason": str(out.get("reason", "")),
            "conflict": bool(out.get("conflict", False))}


# ---------- Tool 4 ----------
def generate_checklist(profile: dict, scheme: dict) -> list:
    docs = list(scheme.get("documents", []))
    for item in scheme.get("conditional_documents", []):
        if rules.condition_met(profile, item["if"]):
            docs.append(item["doc"])
    return docs


# ---------- Tool 5 ----------
def find_links(scheme: dict) -> dict:
    return {"link": scheme.get("link", ""), "steps": scheme.get("steps", [])}


# ---------- Grounded Q&A ----------
def rag_answer(question: str, profile: dict, lang: str) -> dict:
    ev = retriever.search(question, k=5)
    ctx = "\n\n".join(f"[{i+1}] (Source: {e['source']}, p.{e['page']}) {e['text']}" for i, e in enumerate(ev))
    prompt = f"""You are SchemeSaathi, an assistant for Indian government schemes.
Answer ONLY from the context. If the answer is not in the context, say you could not find it in the
official documents and suggest the official portal. Cite sources like [1]. Reply in {LANG_NAMES.get(lang, 'English')}.
Citizen profile (for personalisation): {json.dumps(profile, ensure_ascii=False)}
Context:
{ctx}

Question: {question}"""
    return {"answer": ask(prompt),
            "sources": [{"n": i + 1, "source": e["source"], "page": e["page"], "url": e["url"]}
                        for i, e in enumerate(ev)]}


# ---------- Translation ----------
def translate(text: str, lang: str) -> str:
    if lang in (None, "en"):
        return text
    try:
        return ask(f"Translate to {LANG_NAMES[lang]}. Keep numbers and scheme names. Output only the translation.\n\n{text}")
    except Exception:
        return text
