import json
import rules, config
from eval.cases import load_cases
from models import clean_profile

SCHEMES = json.loads(config.SCHEMES_JSON.read_text(encoding="utf-8"))


def eligible_ids(profile):
    return sorted(s["id"] for s in SCHEMES if rules.evaluate(profile, s)["status"] == rules.ELIGIBLE)


def test_all_hand_labelled_cases():
    for c in load_cases():
        assert eligible_ids(c["profile"]) == sorted(c["expected"]), c["id"]


def test_unknown_value_gives_need_info_not_guess():
    s = next(x for x in SCHEMES if x["id"] == "pm_kisan")
    r = rules.evaluate({"occupation": "farmer", "land_acres": 2}, s)
    assert r["status"] == rules.NEED_INFO and r["missing"] == ["is_income_taxpayer"]


def test_fail_beats_unknown():
    s = next(x for x in SCHEMES if x["id"] == "pm_kisan")
    assert rules.evaluate({"occupation": "salaried"}, s)["status"] == rules.NOT_ELIGIBLE


def test_any_group():
    s = next(x for x in SCHEMES if x["id"] == "pmjay")
    assert rules.evaluate({"is_bpl": False, "age": 72}, s)["status"] == rules.ELIGIBLE
    assert rules.evaluate({"is_bpl": False, "age": 40}, s)["status"] == rules.NOT_ELIGIBLE
    assert rules.evaluate({"is_bpl": False}, s)["status"] == rules.NEED_INFO


def test_clean_profile_coercion():
    p = clean_profile({"age": "45", "annual_income": "90000", "occupation": "Farmer", "is_bpl": "yes",
                       "gender": "alien", "bogus": 1})
    assert p == {"age": 45, "annual_income": 90000.0, "occupation": "farmer", "is_bpl": True}


def test_student_implies_is_student():
    assert clean_profile({"occupation": "student"})["is_student"] is True
