"""multilingual-e5 needs 'query: ' / 'passage: ' prefixes for best retrieval."""
from langchain_core.embeddings import Embeddings


class E5Embeddings(Embeddings):
    def __init__(self, model_name: str):
        from sentence_transformers import SentenceTransformer
        self.model = SentenceTransformer(model_name)

    def embed_documents(self, texts):
        return self.model.encode([f"passage: {t}" for t in texts], normalize_embeddings=True).tolist()

    def embed_query(self, text):
        return self.model.encode(f"query: {text}", normalize_embeddings=True).tolist()
