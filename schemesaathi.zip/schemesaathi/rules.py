"""Deterministic eligibility rule engine (no LLM, no heavy dependencies).

A scheme has rules = {"all": [cond, ...], "any": [cond, ...]}
cond = {"field", "op", "value", "label"}.  Unknown profile values yield NEED_INFO
instead of a guess.
"""
ELIGIBLE, NOT_ELIGIBLE, NEED_INFO = "ELIGIBLE", "NOT_ELIGIBLE", "NEED_INFO"


def _norm(v):
    if isinstance(v, str):
        return v.strip().lower()
    if isinstance(v, list):
        return [_norm(x) for x in v]
    return v


def _fmt(v):
    if isinstance(v, bool):
        return "Yes" if v else "No"
    return str(v)


def check_condition(profile: dict, cond: dict) -> str:
    """Return 'pass', 'fail' or 'unknown'."""
    actual = profile.get(cond["field"])
    if actual is None:
        return "unknown"
    a, v = _norm(actual), _norm(cond["value"])
    ops = {
        ">=": lambda: a >= v, "<=": lambda: a <= v, ">": lambda: a > v, "<": lambda: a < v,
        "==": lambda: a == v, "!=": lambda: a != v,
        "in": lambda: a in v, "not_in": lambda: a not in v,
    }
    try:
        return "pass" if ops[cond["op"]]() else "fail"
    except TypeError:
        return "unknown"


def evaluate(profile: dict, scheme: dict) -> dict:
    rules = scheme.get("rules", {})
    passed, failed, missing = [], [], []

    for c in rules.get("all", []):
        r = check_condition(profile, c)
        if r == "pass":
            passed.append(f"{c['label']} (you: {_fmt(profile[c['field']])})")
        elif r == "fail":
            failed.append(f"{c['label']} (you: {_fmt(profile[c['field']])})")
        else:
            missing.append(c["field"])

    any_c = rules.get("any", [])
    if any_c:
        res = [check_condition(profile, c) for c in any_c]
        names = " OR ".join(c["label"] for c in any_c)
        if "pass" in res:
            passed.append(f"Meets at least one of: {names}")
        elif "unknown" in res:
            missing += [c["field"] for c, r in zip(any_c, res) if r == "unknown"]
        else:
            failed.append(f"None of these apply: {names}")

    status = NOT_ELIGIBLE if failed else NEED_INFO if missing else ELIGIBLE
    return {"status": status, "passed": passed, "failed": failed,
            "missing": list(dict.fromkeys(missing))}


def condition_met(profile: dict, cond: dict) -> bool:
    return check_condition(profile, cond) == "pass"
